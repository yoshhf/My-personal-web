document.addEventListener('DOMContentLoaded', function () {
    const slider = document.querySelector('.slider');
    const slides = document.querySelectorAll('.slider-item');

    let currentIndex = 2; // Start with the third image as the center

    function moveToIndex(index) {
        slider.style.transform = `translateX(-${index * 100}%)`;
        slides.forEach((slide, idx) => {
            slide.classList.remove('active');
            if (idx === index) {
                slide.classList.add('active');
            }
        });
    }

    slides.forEach((slide, index) => {
        slide.addEventListener('click', function () {
            if (index !== currentIndex) {
                currentIndex = index;
                moveToIndex(currentIndex);
            }
        });
    });

    moveToIndex(currentIndex);
});
document.addEventListener('DOMContentLoaded', function () {
    const slider = document.querySelector('.slider');
    const slides = document.querySelectorAll('.slider-item');
    const prevButton = document.querySelector('.slider-button.prev');
    const nextButton = document.querySelector('.slider-button.next');

    let currentIndex = 2; // Start with the third image as the center

    function moveToIndex(index) {
        slider.style.transform = `translateX(-${index * 100}%)`;
        slides.forEach((slide, idx) => {
            slide.classList.remove('active');
            if (idx === index) {
                slide.classList.add('active');
            }
        });
    }

    slides.forEach((slide, index) => {
        slide.addEventListener('click', function () {
            if (index !== currentIndex) {
                currentIndex = index;
                moveToIndex(currentIndex);
            }
        });
    });

    prevButton.addEventListener('click', function () {
        currentIndex = (currentIndex - 1 + slides.length) % slides.length;
        moveToIndex(currentIndex);
    });

    nextButton.addEventListener('click', function () {
        currentIndex = (currentIndex + 1) % slides.length;
        moveToIndex(currentIndex);
    });

    moveToIndex(currentIndex);
});


document.addEventListener('DOMContentLoaded', function() {
    const menuIcon = document.querySelector('.menu-icon');
    const navLinks = document.querySelector('.nav-links');

    menuIcon.addEventListener('click', function() {
        navLinks.classList.toggle('active');
    });

    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!menuIcon.contains(event.target) && !navLinks.contains(event.target)) {
            navLinks.classList.remove('active');
        }
    });
});